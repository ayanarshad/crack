Run, Chose language, Install & Enjoy, no activation required on first run.

Use any random letter to register, Example: type a in both boxes.

NOTE: Exclude the app via A/V program to avoid False positive infections, No harm by these infections, read more at torrent page description.


